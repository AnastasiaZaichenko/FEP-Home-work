const $rootEl = $("#root");
new Controller($rootEl);
