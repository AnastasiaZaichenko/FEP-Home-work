const $rootEl = $("#container");

const controller = new Controller($rootEl);
