class ContactFormView {
  constructor(options) {
    this.$form = this.init();
    this.$inputs = this.$form.find("input, textarea");
    this.options = options;
  }

  init() {
    return $(`
    <form id="contactForm" class="form">
    <input type="text" id="nameInput"    class="formInput" />
    <input type="text" id="surnameInput" class="formInput" />
    <input type="text" id="phoneInput"   class="formInput"  />
    <input type="hidden" id="id" class="formInput"  />

    <button id="addContactBtn">Add Contact</button>
  </form>
    `).on(`submit`, this.onFormSubmit.bind(this));
  }

  onFormSubmit(e) {
    e.preventDefault();

    const contact = this.getContact();
    console.log(contact);

    // if (!this.isContactValid(contact)) {
    //   this.showError(new Error("Невалидные данные"));
    //   return;
    // }

    this.options.onSubmit(contact);
  }

  appendTo($el) {
    $el.append(this.$form);
  }

  getContact() {
    // const contact = findContactById(id) || {};

    // const result = {
    //   ...contact,
    //   name: form.nameInput.value,
    //   surname: form.surnameInput.value,
    //   phone: form.phoneInput.value,
    // };

    // return result;
    const contact = {};
    for (const input of this.$inputs) {
      contact[input.id] = input.value;
    }
    return contact;

    // console.log(contact);
  }

  setContact(contact) {
    for (const input of this.$inputs) {
      input.value = contact[input.id];
    }
    // console.log(contact);
    // const { name, surname, phone, id } = contact;
    // form.nameInput.value = name;
    // form.surnameInput.value = surname;
    // form.phoneInput.value = phone;
    // form.id.value = id;
  }

  clearForm() {
    for (const input of this.$inputs) {
      input.value = "";
    }
  }

  isContactValid(contact) {
    return (
      contact.name && contact.surname && contact.phone && !isNaN(contact.phone)
    );
  }

  // showError(error) {
  //   alert(error.message);
  // }
}
